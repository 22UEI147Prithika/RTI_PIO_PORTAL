import React from 'react';

function ResetPassword() {
  return (
    <div className="text-center mt-5">
      <h2>Reset Password</h2>
      <p>Feature coming soon: Enter your email to reset your password.</p>
    </div>
  );
}

export default ResetPassword;
