function Footer() {
    return (
        <div className="footer">
          <h1 className="H1" >Content of the portal is provided by the Administrative Reforms, Training, Pension, and Public Grievances Department, Government of Tripura.</h1>
<hr />
<h1 className="H2">Copyright © 2025. All rights reserved. This portal is maintained by the Tripura Information Commission and designed & developed by the National Informatics Centre, Tripura.</h1>

        </div>
    );
}
export default Footer;